# OneShot MVP - Clean Foundation

**Menu-Driven Development Approach** • **Single AI Implementation** • **Complexity-Controlled**

## 🎯 Project Overview

OneShot is an AI-generated recruiting platform for high school athletes. This clean foundation represents a **97% complexity reduction** from the original codebase, implementing the breakthrough **Menu-Driven Development** approach.

### **Core Concept**
Athletes create mobile-optimized profiles that coaches can access via QR codes without login complexity.

### **Technical Approach**  
JSON source of truth → Static HTML generation → CDN hosting → Progressive PWA enhancement

---

## 📁 Foundation Structure

```
oneshot-mvp-clean/
├── patterns/              # Pre-approved implementation patterns
├── templates/             # HTML templates for static generation
├── data/                  # JSON storage (git ignored)
├── static/                # Generated HTML files (git ignored) 
├── server/                # Minimal API server code
└── docs/                  # AI context & progress tracking
    ├── ai-context/        # Documentation for AI sessions
    └── progress/          # Feature completion tracking
```

**Current Status**: 0 lines of code • Ready for first Menu-Driven Development session

---

## 🚀 Menu-Driven Development Process

### **How It Works**
1. **Eric describes business need** (product owner language)
2. **AI proposes 2-3 technical options** (pre-approved patterns)
3. **Eric chooses preferred approach** (no technical knowledge required)
4. **AI confirms implementation details**
5. **Eric approves**
6. **AI implements exactly as approved** (no creativity/additions)

### **Example Session**
```
Eric: "I want athletes to upload photos"

AI Options:
Option 1: Single photo upload (simple)
Option 2: Multiple photos with gallery (medium)  
Option 3: Single photo + basic editing (medium)

Eric: "Option 1"

AI: "Implementing Pattern A: Single Photo Upload
- Multer middleware for file handling
- JPEG/PNG validation
- Generate profile with photo display
Verification: Upload photo, see it in profile"

Eric: "Approved"

AI: [Implements exactly as described]
```

---

## 🎯 MVP Features (Locked Scope)

### **✅ Must Have**
- Athlete profile creation & editing
- Photo upload (headshot, action shots)
- File upload (transcript PDF)
- Video links (YouTube/Hudl embed)
- QR code generation
- Public profile pages (static HTML)
- Privacy controls (public/private)
- Mobile optimization

### **❌ Forbidden (Never Build)**
- Admin dashboards
- Analytics/tracking systems
- ML/AI features
- Real-time notifications
- Complex user roles
- Search/discovery features
- Social features

---

## 🏗️ Architecture Decisions (Locked)

### **Static Generation + Progressive PWA**
```yaml
Phase 1: JSON → Static HTML (bulletproof core)
Phase 2: PWA editing interface (enhanced UX)
Authentication: Magic URLs (no passwords)
Storage: JSON files + Generated HTML
Hosting: CDN + minimal API server
```

### **Why This Architecture**
- ✅ Eliminates 80% of failure modes (static files can't break)
- ✅ Eric can verify everything (visible outcomes)
- ✅ Mobile-optimized by default
- ✅ Progressive enhancement (PWA adds features, doesn't replace core)

---

## 📋 Verification System

**Eric tests every feature with 4 questions only:**
1. Does it do what I wanted?
2. Does it work on my phone?
3. Is it confusing for athletes?
4. Is it confusing for coaches?

**Complexity Budget**: <2,000 lines of code total

---

## 🔧 Development Workflow

### **Git Strategy (Simplified)**
```bash
main                    # Production code
develop                 # Feature integration
feature/[description]   # AI session work
```

### **AI Session Protocol**
```bash
git checkout develop
git checkout -b feature/profile-creation
git tag checkpoint/before-profile-creation
[AI implements feature]
git tag checkpoint/after-profile-creation
[Eric verifies & approves]
git checkout develop && git merge feature/profile-creation
```

### **Emergency Recovery**
```bash
git reset --hard checkpoint/before-[session]
```

---

## 📚 Key Documentation

### **For AI Sessions** (`docs/ai-context/`)
- `LESSONS-LEARNED-SYSTEM-V2.md` - Menu-Driven Development breakthrough
- `MVP-ARCHITECTURE-DECISIONS.md` - Technical architecture (locked)
- `AI-SESSION-GUIDELINES.md` - Behavioral rules for AI
- `IMPLEMENTATION-PATTERNS.md` - Pre-approved patterns library
- `GIT-WORKFLOW-SIMPLIFIED.md` - Git discipline without complexity

### **For Progress Tracking** (`docs/progress/`)
- `CURRENT-PROJECT-STATE.md` - Living progress document
- `MVP-FEATURE-TRACKER.md` - Feature completion status

---

## 🚦 Getting Started

### **Prerequisites**
- Node.js 18+
- Git
- Text editor

### **First Session Setup**
```bash
# Clone and enter directory
cd oneshot-mvp-clean

# Initialize git (if not already done)
git init
git remote add origin [your-repo]

# Create initial development branch
git checkout -b develop

# Ready for first Menu-Driven Development session
```

### **What's Next**
The first development session should implement **Profile Creation** using Menu-Driven Development:

1. Eric describes: "I want athletes to create basic profiles"
2. AI proposes pattern options
3. Eric chooses approach
4. AI implements chosen pattern
5. Eric verifies with 4 questions

---

## 💡 Key Insights & Breakthroughs

### **Menu-Driven Development Discovery**
The breakthrough that solved the "Assembly Line" problem where non-technical founders had to give technical instructions. Instead:
- **AI translates business needs to technical options**
- **Eric chooses from options (no technical knowledge required)**
- **AI implements exactly as chosen (no creativity)**

### **Clean Foundation Benefits**
- 97% complexity reduction (9,500+ → 300 lines)
- All breakthrough insights preserved
- Pre-approved patterns for rapid development
- Eric-verifiable outcomes only
- Emergency rollback protocols

### **Single AI Approach**
Simplified from multi-AI IAIS system to single AI (Claude) for:
- Clear accountability
- Simplified workflow  
- Direct Eric-to-AI communication
- Reduced coordination overhead

---

## 🛡️ Quality Safeguards

### **Complexity Control**
- Pre-approved patterns only
- 2,000 line maximum
- Eric-verifiable features only
- Graceful degradation required

### **Emergency Protocols**
- Checkpoint system for rollback
- Static profiles always work
- API failures don't break core functionality
- Git recovery procedures

### **Mobile-First**
- All profiles mobile-optimized
- QR codes work on any device
- <1 second load times
- Progressive enhancement approach

---

## 📞 Team Structure

- **Eric** – Non-technical founder & product owner. Final verifier.
- **Claude** – AI developer. Executes Menu-Driven Development.
- **Menu-Driven Development** – Process that bridges non-technical product vision to technical implementation.

---

**This foundation is optimized for Menu-Driven Development success and Eric's verification abilities. Any deviation requires explicit approval and documentation update.** 