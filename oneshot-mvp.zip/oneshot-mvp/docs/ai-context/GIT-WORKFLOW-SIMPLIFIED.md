# SIMPLIFIED GIT WORKFLOW
**Created**: 2025-01-20  
**Status**: REQUIRED - All AI sessions must follow this workflow  
**Purpose**: Maintain code discipline without complexity overhead

## CORE PRINCIPLE
**Simple, disciplined git workflow optimized for Menu-Driven Development and single AI sessions.**

## REPOSITORY STRUCTURE (SIMPLIFIED)

### **Single Repository Approach**:
```
oneshot-mvp-clean/
├── .git/                    # Single repo (not multi-repo)
├── patterns/                # Implementation patterns
├── templates/               # HTML templates
├── data/                   # JSON storage
├── static/                 # Generated files (git ignored)
├── server/                 # API server code
└── docs/                   # Documentation
```

### **Why Single Repo**:
- ✅ **Menu-Driven Development works in single sessions**
- ✅ **Eric verifies complete features, not fragments**
- ✅ **Simpler for single AI approach**
- ✅ **Easier rollback and emergency recovery**

## BRANCH STRATEGY (SIMPLIFIED)

### **Three-Branch Model**:
```bash
main                        # Working production code only
develop                     # Integration of complete features  
feature/[description]       # AI session work (one per session)
```

### **No Hotfix Complexity**:
- Emergency fixes go through same feature branch process
- Fast-forward merges only (no complex merge conflicts)
- Each feature branch is complete and working

## AI SESSION WORKFLOW

### **Session Start Protocol**:
```bash
# Always start from develop
git checkout develop
git pull origin develop

# Create session branch  
git checkout -b feature/profile-creation
# or feature/qr-code-generation
# or feature/file-uploads

# Create checkpoint before work
git tag checkpoint/before-[session-description]
git push --tags
```

### **During Session Protocol**:
```bash
# Make small, frequent commits
git add [specific-files]  # Never use git add .
git commit -m "feat(profile): add basic form fields"

# Push regularly for backup
git push origin feature/[current-branch]
```

### **Session End Protocol**:
```bash
# Final checkpoint
git tag checkpoint/after-[session-description]
git push --tags

# Merge to develop if Eric approves
git checkout develop
git merge feature/[session-branch] --no-ff
git push origin develop

# Clean up
git branch -d feature/[session-branch]
```

## COMMIT MESSAGE FORMAT (REQUIRED)

### **Simple Format**:
```bash
type(scope): brief description

# Examples:
feat(profile): add athlete name and school fields
fix(qr): correct QR code generation for long URLs  
docs(progress): update MVP progress tracker
```

### **Commit Types**:
```yaml
feat: New feature (what Eric can see/test)
fix: Bug fix (what was broken, now works)
docs: Documentation update
refactor: Code improvement (no behavior change)
```

### **Scope Examples**:
```yaml
profile: Profile creation/editing features
qr: QR code generation
upload: File upload functionality
template: HTML template changes
auth: Authentication features
```

## VERIFICATION INTEGRATION

### **Commit-Level Verification**:
```bash
# Each commit should include:
git commit -m "feat(profile): add photo upload

What: Athletes can upload profile photos
Verification: Eric can upload photo, see it display correctly
Files: server/upload.js, templates/profile-page.html"
```

### **Feature Branch Verification**:
```yaml
Branch Complete When:
- Eric can test the feature end-to-end
- Feature works on Eric's phone
- All 4 verification questions pass
- Documentation updated
```

## FILE MANAGEMENT

### **What to Track**:
```bash
# Always track:
patterns/               # Implementation patterns
templates/              # HTML templates  
server/                # API server code
docs/                  # Documentation
package.json           # Dependencies
*.md                   # Documentation files

# Never track:
static/                # Generated HTML files
data/                  # JSON storage (private data)
node_modules/          # Dependencies
*.log                  # Log files
.env                   # Environment variables
```

### **.gitignore (Essential)**:
```bash
# Generated files
static/
data/profiles/
data/users/

# Dependencies  
node_modules/
*.log

# Environment
.env
.env.local

# System files
.DS_Store
Thumbs.db
```

## CHECKPOINT SYSTEM (SIMPLIFIED)

### **Required Checkpoints**:
```bash
# Before each AI session
git tag checkpoint/before-[session-name]

# After successful AI session  
git tag checkpoint/after-[session-name]

# Before major changes
git tag checkpoint/stable-[date]

# Examples:
checkpoint/before-profile-creation
checkpoint/after-profile-creation
checkpoint/stable-2025-01-20
```

### **Recovery Protocol**:
```bash
# If session breaks things:
git log --oneline                    # Find last good commit
git reset --hard checkpoint/before-[session]
git push --force-with-lease         # Update remote safely

# Or reset to specific commit:
git reset --hard [commit-hash]
git push --force-with-lease
```

## EMERGENCY PROTOCOLS

### **If Git Gets Messy**:
```bash
# Save current work
git checkout -b emergency/save-work-$(date +%Y%m%d)
git add . && git commit -m "emergency: save current state"
git push origin emergency/save-work-$(date +%Y%m%d)

# Reset to last known good state
git checkout main
git reset --hard checkpoint/stable-[latest]
git push --force-with-lease

# Start fresh session
git checkout -b feature/recovery-[task]
```

### **If Need to Undo Recent Work**:
```bash
# Undo last commit (but keep changes)
git reset --soft HEAD~1

# Undo last commit (lose changes)  
git reset --hard HEAD~1

# Undo multiple commits
git reset --hard checkpoint/before-[session]
```

## INTEGRATION WITH MENU-DRIVEN DEVELOPMENT

### **Session Planning**:
```yaml
Eric Request: "I want athletes to upload photos"
AI Session Plan: 
- Branch: feature/photo-upload
- Checkpoint: before-photo-upload  
- Verification: Eric uploads photo, sees it display
- Merge: to develop after Eric approval
```

### **Success Criteria**:
```yaml
Git Success When:
- Eric can see what each commit changed
- Any session can be completely undone
- Main branch always works
- Emergency rollback takes <2 minutes
- Git history tells story of development
```

## SIMPLIFIED VALIDATION

### **Basic Pre-Commit Check**:
```bash
# .git/hooks/pre-commit (optional)
#!/bin/bash

# Prevent commits to main
if [ "$(git rev-parse --abbrev-ref HEAD)" = "main" ]; then
  echo "❌ Direct commits to main branch forbidden"
  exit 1
fi

# Check commit message format
commit_msg=$(git log --format=%B -n 1 HEAD)
if ! echo "$commit_msg" | grep -qE "^(feat|fix|docs|refactor)\(.+\): .{10,}"; then
  echo "❌ Commit message format: type(scope): description"
  exit 1
fi

echo "✅ Git validation passed"
```

## DAILY GIT HEALTH

### **Simple Status Check**:
```bash
# scripts/git-status.sh
#!/bin/bash

echo "=== Git Health Check ==="
echo "Current branch: $(git rev-parse --abbrev-ref HEAD)"
echo "Uncommitted changes: $(git status --porcelain | wc -l)"
echo "Last checkpoint: $(git tag | grep checkpoint | tail -1)"
echo "Last commit: $(git log --oneline -1)"

if [ "$(git status --porcelain | wc -l)" -gt 0 ]; then
  echo "⚠️  Uncommitted changes detected"
fi
```

---

**This simplified workflow maintains discipline without complexity overhead, optimized for Menu-Driven Development sessions.** 