# MVP ARCHITECTURE DECISIONS
**Created**: 2025-01-20  
**Status**: AUTHORITATIVE - All future AI sessions must follow this  
**Source**: Refined after Menu-Driven Development breakthrough

## CORE ARCHITECTURAL DECISION (LOCKED)

### **Approach**: Static Generation + Progressive PWA Enhancement
```
Phase 1: JSON → Static HTML profiles (bulletproof core)
Phase 2: PWA editing interface (enhanced UX, optional)
Storage: JSON source of truth + Generated HTML files
Hosting: CDN for static files + minimal API server
Authentication: Magic URLs (no login complexity)
```

### **Why This Architecture**:
- ✅ **Eliminates 80% of failure modes** (static files can't break)
- ✅ **Eric can verify everything** (visible outcomes, not internal logic)
- ✅ **Mobile-optimized by default** (static HTML loads fast)
- ✅ **Progressive enhancement** (PWA adds features, doesn't replace core)

## TECHNICAL STACK (FINAL)

### **Phase 1 (Core MVP)**:
```yaml
Data Storage: JSON files (human-readable, version-controllable)
HTML Generation: Server-side template → static file generation
Frontend: Static HTML + CSS + minimal JavaScript
Backend: Express.js + basic API endpoints (generation only)
Database: Simple user table + JSON profile storage
Authentication: Magic URLs (32-char random tokens)
Hosting: CDN (Vercel/Netlify) + minimal API server
```

### **Phase 2 (Enhancement)**:
```yaml
PWA Interface: React + Vite + Tailwind (editing only)
Service Worker: Cache static profiles for offline access
App Installation: Web app manifest + install prompts
Enhanced UX: Real-time preview, drag-drop uploads
```

## DATA FLOW (LOCKED)

### **Profile Creation Flow**:
```
1. User fills form → Validate data → Save JSON file
2. JSON data + Template → Generate static HTML
3. Save HTML to CDN → Return public URL + edit token
4. User gets: Public profile URL + QR code + Edit link
```

### **Profile Editing Flow**:
```
1. User accesses edit/[token] → Load JSON data into form
2. User makes changes → Validate → Update JSON file
3. Regenerate HTML from updated JSON → Save to CDN
4. Updated profile immediately available at same URL
```

### **Profile Viewing Flow**:
```
1. Coach scans QR code → Direct to static HTML URL
2. HTML loads instantly from CDN (no database queries)
3. All content visible (name, stats, photo, transcript)
4. No login required, works on any device
```

## FILE STRUCTURE (LOCKED)

```
oneshot-mvp-clean/
├── patterns/              # Pre-approved implementation patterns
├── templates/             # HTML templates for generation  
│   ├── profile-page.html  # Main athlete profile template
│   └── error-page.html    # Fallback for broken links
├── data/                  # JSON storage
│   ├── users/[id].json    # User account data
│   └── profiles/[slug].json # Athlete profile data
├── static/                # Generated files (CDN-hosted)
│   └── profiles/[slug].html # Static profile pages
├── server/                # Minimal API server
│   ├── app.js            # Main server setup
│   ├── auth.js           # Magic URL authentication
│   ├── generator.js      # JSON → HTML conversion
│   └── validator.js      # Input validation
└── docs/                  # Documentation & progress tracking
```

## AUTHENTICATION STRATEGY (LOCKED)

### **Magic URLs (No Password Complexity)**:
```yaml
Profile Creation: Register → Get edit token → Create profile
Profile Editing: /edit/[32-char-token] (unguessable, secure)
Profile Viewing: /profiles/[athlete-slug].html (public if enabled)
No login forms, password resets, or session management
```

### **Privacy Controls**:
```yaml
Profile Level: Public/Private toggle (show/hide entire profile)
Field Level: Individual fields can be hidden (GPA, contact info)
Implementation: JSON flags control what appears in generated HTML
```

## MVP FEATURES (LOCKED SCOPE)

### **✅ INCLUDED (Must Have)**:
- Athlete profile creation & editing (name, school, position, stats)
- Photo upload (headshot, action shots)
- File upload (transcript PDF)
- Video links (YouTube/Hudl embed)
- QR code generation (for coach scanning)
- Public profile pages (static HTML, mobile-optimized)
- Privacy controls (public/private, field visibility)
- Edit functionality (via magic URLs)
- Error handling (graceful fallbacks)

### **❌ FORBIDDEN (Never Build)**:
- Admin dashboards
- Analytics/tracking systems
- ML/AI features
- Real-time notifications
- Complex user roles (coach/parent accounts)
- Search/discovery features
- Social features (messaging, following)
- Advanced workflow systems

## COMPLEXITY PRINCIPLES (NON-NEGOTIABLE)

### **Verification Boundary**:
```yaml
Eric Can Verify: Profile displays correctly, QR codes work, files upload
Eric Cannot Verify: Internal code logic, security implementation, performance
Rule: Only build what Eric can meaningfully test in 30 seconds
```

### **Complexity Budget**:
```yaml
Maximum: 2,000 lines of code total
Approach: Pre-tested patterns only, no custom complex logic
Enforcement: Menu-Driven Development constrains choices
```

### **Failure Isolation**:
```yaml
Static Profiles: Must work even if PWA/API fails
Core Features: Independent of enhancement features
Error Handling: Graceful degradation to basic functionality
```

## MENU-DRIVEN DEVELOPMENT INTEGRATION

### **How Architecture Decisions Work with Menu-Driven Development**:
```yaml
Eric Describes Need: "I want coaches to easily access athlete info"
AI Proposes Options: Within this architectural framework only
Eric Chooses: From pre-approved patterns and approaches
AI Implements: Exactly as specified, no architectural changes
```

### **Pattern Library Constraints**:
```yaml
All patterns must: 
- Generate static HTML output
- Use JSON source of truth
- Work within file structure above
- Respect complexity budget
- Be Eric-verifiable
```

## DEPLOYMENT STRATEGY (SIMPLIFIED)

### **Static Files (CDN)**:
```yaml
Host: Vercel/Netlify
Content: Generated HTML profiles, images, assets
Performance: <1 second load time globally
Reliability: 99.9% uptime (no database dependencies)
```

### **API Server (Minimal)**:
```yaml
Host: Railway/Render
Purpose: Profile generation, file uploads only
Size: <500 lines of code total
Reliability: Can be down without breaking profile viewing
```

## SUCCESS CRITERIA

### **Technical Success**:
- ✅ Static profiles load in <1 second
- ✅ QR codes scan successfully on iOS/Android
- ✅ Generated HTML displays correctly on mobile
- ✅ File uploads complete without errors
- ✅ Privacy toggles work reliably

### **Process Success**:
- ✅ Eric can create/edit profiles without technical knowledge
- ✅ All features verifiable with 4 simple questions
- ✅ Menu-Driven Development produces expected results
- ✅ No features exceed approved scope
- ✅ Complexity stays under budget

### **Real-World Success (MVP Completion Checkpoint)**:
- ✅ 5+ real athletes can create profiles without confusion
- ✅ 3+ real coaches can access profiles via QR codes successfully
- ✅ System works at actual recruiting camp or event
- ✅ Upload/download functions work on various devices
- ✅ No critical usability issues identified by real users

## REAL-WORLD TESTING PROTOCOL

### **Before Declaring MVP Complete**:
```yaml
Phase 1: Internal Testing (Eric + immediate contacts)
- Eric creates 3 test profiles successfully
- Eric's contacts test QR code scanning
- All 4 verification questions pass for all features

Phase 2: Limited Real-World Testing  
- Recruit 5 athletes to create actual profiles
- Recruit 3 coaches to access profiles via QR codes
- Test at small-scale event (not major camp)
- Document all usability issues

Phase 3: Issue Resolution
- Fix critical issues using existing patterns only
- If pattern changes needed: Eric approves changes
- Re-test with subset of Phase 2 users

Phase 4: MVP Validation
- All users can complete core workflows
- No show-stopping issues remain
- System ready for larger-scale deployment
```

### **Real-World Testing Guidelines**:
```yaml
User Selection:
- Athletes: High school age, varying tech comfort levels
- Coaches: Mix of young/older, various tech backgrounds
- Test environment: Simulate recruiting camp conditions

Success Metrics:
- 80%+ task completion rate without help
- <2 minutes average profile creation time
- QR codes work 95%+ of the time on first scan
- No user reports "this is confusing"

Failure Thresholds:
- Any user cannot complete basic profile creation
- QR codes fail >20% of scans
- More than 2 users report significant confusion
- Critical functionality breaks on any common device
```

## EMERGENCY PROTOCOLS

### **If Static Generation Breaks**:
```yaml
1. Profiles still viewable (CDN cached)
2. Fall back to error.html page
3. Fix generation API independently
4. Regenerate all profiles from JSON source
```

### **If Static Generation Hits Fundamental Limits**:
```yaml
Prepared Escape Hatches (in order of preference):

Escape Hatch 1: Minimal Dynamic API
- Keep static profiles for viewing (core value preserved)
- Add single API endpoint for forms/uploads only
- JSON source of truth maintained
- 95% static, 5% dynamic
- Complexity increase: ~200 lines

Escape Hatch 2: Hybrid Static + Dynamic Forms  
- Static profiles for coaches (viewing)
- Dynamic interface for athletes (editing)
- Two-tier architecture maintains core benefits
- Complexity increase: ~400 lines

Escape Hatch 3: Progressive Enhancement Acceleration
- Implement Phase 2 PWA immediately
- Static files become fallback/cache layer
- Dynamic editing becomes primary interface
- Full pivot while preserving static infrastructure
- Complexity increase: ~800 lines

Never Do: Rebuild from scratch
```

### **Trigger Criteria for Escape Hatches**:
```yaml
Use Escape Hatch 1 if:
- File uploads require server processing
- Form validation needs server-side logic
- Authentication needs server state

Use Escape Hatch 2 if:
- Real-time features become essential
- Complex form workflows required
- Mobile app experience needed

Use Escape Hatch 3 if:
- Static approach fundamentally inadequate
- User feedback demands dynamic features
- Performance requires client-side processing
```

### **If Menu-Driven Development Fails**:
```yaml
1. Reset to last checkpoint
2. Document what went wrong
3. Simplify approach further
4. Update patterns to prevent recurrence
```

---

**This architecture is optimized for Menu-Driven Development and Eric's verification abilities. Any deviation requires explicit approval and architecture document update.** 