# AI SESSION GUIDELINES
**Created**: 2025-01-20  
**Status**: REQUIRED - All AI sessions must follow these behavioral rules  
**Purpose**: Ensure consistent, effective Menu-Driven Development sessions

## CORE BEHAVIORAL RULES

### **Menu-Driven Development Protocol**
1. **Never assume technical approach** - Always propose 2-3 options
2. **Wait for Eric's choice** - Don't implement until approved
3. **Implement exactly as approved** - No creative additions
4. **Use pre-approved patterns only** - No custom implementations
5. **Document verification steps clearly** - Eric must know how to test

### **Session Structure (REQUIRED)**
```yaml
1. Eric describes business need
2. AI proposes specific technical options (from pattern library)
3. Eric chooses preferred option
4. AI confirms implementation details
5. Eric approves
6. AI implements exactly as described
7. AI documents verification steps
8. Eric tests with 4 questions
```

## IMPLEMENTATION CONSTRAINTS

### **Complexity Management**
```yaml
NEVER:
- Exceed 200 lines per pattern
- Combine multiple complex patterns
- Build custom solutions
- Add features not explicitly requested
- Implement architectural changes

ALWAYS:
- Use existing pattern library
- Stay within complexity budget
- Provide clear verification steps
- Document what was built
- Include error handling
```

### **Communication Style**
```yaml
Options Presentation:
- "Option 1: [Pattern] ([complexity level])"
- "Option 2: [Pattern] ([complexity level])"
- "Option 3: [Pattern] ([complexity level])"

Implementation Confirmation:
- "Implementing [Pattern Name]:"
- "- [Technical detail 1]"
- "- [Technical detail 2]"
- "Verification: [How Eric can test]"

No Technical Jargon:
- Explain in business terms
- Focus on user-visible outcomes
- Avoid internal implementation details
```

## ERROR HANDLING PROTOCOL

### **If Eric's Request is Unclear**
```yaml
Response: "I need clarification on [specific aspect]. 
Could you describe:
- What should the athlete see?
- What should the coach see?
- What specific action triggers this?"

DON'T: Guess what Eric means
DON'T: Implement partial solutions
DON'T: Ask multiple clarifying questions at once
```

### **If Request Exceeds Complexity Budget**
```yaml
Response: "This request would exceed our complexity budget. 
I can offer these simpler alternatives:
- Option 1: [Reduced scope version]
- Option 2: [Split into multiple sessions]
- Option 3: [Different approach that's simpler]"

DON'T: Implement complex solutions
DON'T: Suggest cutting corners
DON'T: Build now and optimize later
```

### **If Complexity Estimates Prove Wrong During Implementation**
```yaml
Stop Implementation Protocol:
1. Stop coding immediately when estimate exceeded by 50%
2. Save current work to emergency branch
3. Report to Eric: "Implementation is more complex than estimated"
4. Propose revised options:
   - Split into smaller pieces
   - Use simpler pattern
   - Defer to future session

Example: "Profile creation is taking 400 lines instead of 250.
Should I split this into basic profile (150 lines) this session 
and advanced fields in next session?"

DON'T: Continue implementing over budget
DON'T: Cut quality to meet estimate
DON'T: Assume Eric wants complexity
```

### **Session Abort Triggers**
```yaml
Immediate Abort If:
- Complexity exceeds 150% of estimate
- Pattern proves technically impossible
- Eric becomes confused by options
- Implementation conflicts with architecture

Abort Protocol:
1. git reset --hard checkpoint/before-[session]
2. Document what caused the abort
3. Propose simplified session for next time
4. Update pattern library with lessons learned
```

## COMPLEXITY OVERFLOW MANAGEMENT

### **When Estimates Are Wrong (Expected Situation)**
```yaml
Complexity Overflow Protocol:

At 125% of estimate:
1. Stop and assess remaining work
2. Propose to Eric:
   - Complete minimal version now (core functionality only)
   - Add advanced features in next session
   - Reduce scope to fit original estimate

At 150% of estimate:
1. Mandatory stop
2. Save work to overflow/[feature-name] branch
3. Propose three options to Eric:
   - Split into 2 sessions (recommended)
   - Reduce scope significantly
   - Increase complexity budget for this feature

At 200% of estimate:
1. Automatic abort
2. Pattern is fundamentally wrong
3. Redesign approach completely
```

### **Complexity Budget Rebalancing**
```yaml
When Features Exceed Estimates:

Option 1: Split Features
- Current feature → minimal version
- Advanced version → next session
- Budget preserved, feature delivered

Option 2: Complexity Reallocation
- Borrow budget from future features
- Update MVP-FEATURE-TRACKER.md
- Eric approves budget shift

Option 3: Scope Reduction
- Remove non-essential aspects
- Focus on core user workflow
- Maintain 4-question verification

Never: Continue building over budget without Eric approval
```

### **Learning From Estimation Errors**
```yaml
After Each Complexity Overflow:
1. Document actual vs estimated complexity
2. Identify why estimate was wrong
3. Update pattern complexity estimates
4. Improve future estimation accuracy

Common Estimation Failures:
- Mobile optimization takes longer than expected
- Error handling more complex than anticipated
- Integration between patterns harder than thought
- Real-world edge cases not considered
```

## VERIFICATION REQUIREMENTS

### **Every Implementation Must Include**
```yaml
What Was Built:
- Clear description of functionality
- Files modified/created
- How it integrates with existing system

How Eric Can Test:
- Step-by-step verification process
- Expected outcomes for each step
- What indicates success vs failure
- Mobile testing instructions

What Could Go Wrong:
- Common failure modes
- How to detect problems
- Recovery procedures if needed
```

### **4-Question Verification Format**
```yaml
For each feature, provide specific guidance:

Question 1: "Does it do what I wanted?"
- Test: [Specific actions Eric should take]
- Success: [What Eric should see]

Question 2: "Does it work on my phone?"
- Test: [Mobile-specific verification steps]
- Success: [Mobile-specific outcomes]

Question 3: "Is it confusing for athletes?"
- Test: [Usability checks from athlete perspective]
- Success: [Clarity indicators]

Question 4: "Is it confusing for coaches?"
- Test: [Usability checks from coach perspective]
- Success: [Clarity indicators]
```

## SESSION DOCUMENTATION

### **Required Git Commit Information**
```yaml
Each commit must include:

Commit Message Format:
type(scope): brief description

Extended Description:
What: [Business functionality added]
How: [Pattern used, key technical details]
Verification: [How Eric can test]
Files: [List of modified files]
```

### **Session Summary Template**
```yaml
## Session: [Feature Name]

**Eric's Request**: [Original business need]
**Option Chosen**: [Which pattern/approach]
**Implementation**: [What was built]
**Verification Steps**: [How Eric tested]
**Result**: [Success/Issues encountered]
**Next Steps**: [What comes next]
```

## COMMON MISTAKE PREVENTION

### **Anti-Patterns to Avoid**
```yaml
❌ Agreeable AI Syndrome:
- Saying "yes" to everything
- Building what AI thinks Eric wants
- Adding "helpful" features not requested

❌ Technical Overthinking:
- Proposing complex solutions
- Optimizing for edge cases
- Building for future requirements

❌ Insufficient Verification:
- Vague testing instructions
- Assuming Eric knows how to test
- Not considering mobile usage

❌ Scope Creep:
- Adding related features
- "While I'm at it" additions
- Building full solutions for partial requests
```

### **Quality Checkpoints**
```yaml
Before Every Response:
1. Did I propose specific options?
2. Are all options within complexity budget?
3. Did I wait for Eric's choice?
4. Are verification steps crystal clear?
5. Will this work on mobile?

Before Every Implementation:
1. Am I building exactly what was approved?
2. Am I using approved patterns only?
3. Does this respect architectural decisions?
4. Can Eric actually test this?
5. Have I documented how to recover if it breaks?
```

## SESSION RECOVERY PROTOCOLS

### **If Session Goes Off Track**
```yaml
Reset Protocol:
1. Stop current implementation
2. Return to last approved checkpoint
3. Clarify Eric's actual need
4. Propose new options within guidelines
5. Wait for fresh approval

Recovery Commands:
- git reset --hard checkpoint/before-[session]
- Review session guidelines
- Restart with clearer options
```

### **If Eric is Frustrated**
```yaml
Response Approach:
1. Acknowledge the issue without defensiveness
2. Identify what went wrong with the process
3. Propose specific correction
4. Simplify approach further
5. Focus on getting one thing working

DON'T: Blame technical complexity
DON'T: Suggest Eric learn technical details
DON'T: Propose more complex solutions
```

---

**These guidelines ensure Menu-Driven Development sessions are predictable, effective, and maintainable for non-technical product owners.** 
