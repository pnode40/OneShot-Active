# AI Context Documentation

This directory contains **mandatory reading** for all AI development sessions on the OneShot MVP project.

## **MAJOR BREAKTHROUGH: Menu-Driven Development (V2)**

**Latest Discovery**: We identified a fatal flaw in our "Assembly Line" approach and created a breakthrough solution called **Menu-Driven Development**.

**Critical Reading**: `LESSONS-LEARNED-SYSTEM-V2.md` - This document represents our most important breakthrough and must be read before any development.

## Purpose

These documents solve the **AI memory gap problem** - ensuring that architectural decisions, scope constraints, and project state persist between AI sessions, preventing scope creep and maintaining system coherence.

## How to Use

### For AI Sessions:
1. **START WITH V2 SYSTEM** - Read `LESSONS-LEARNED-SYSTEM-V2.md` first
2. **Read context documents** - Understand current state and constraints
3. **Follow Menu-Driven process** - Propose options, don't make decisions
4. **Update documentation** - Keep project state current after each session

### For Eric:
1. **Use Menu-Driven approach** - Describe business needs, choose from AI options
2. **Reference for scope enforcement** - Use to reject out-of-scope AI suggestions
3. **Progress tracking** - Check current project state for status updates
4. **Emergency recovery** - Use protocols when things break

## Document Overview

### 🎯 [LESSONS-LEARNED-SYSTEM-V2.md](./LESSONS-LEARNED-SYSTEM-V2.md) **[START HERE]**
**BREAKTHROUGH DISCOVERY** - Menu-Driven Development approach
- Solves the "Assembly Line" fatal flaw (Eric giving technical instructions)
- Eric as Product Owner, AI as Technical Translator
- Progressive disclosure: Business need → Technical options → Implementation
- Pattern library approach with 4-question verification

### 📋 [MVP-ARCHITECTURE-DECISIONS.md](./MVP-ARCHITECTURE-DECISIONS.md)
**AUTHORITATIVE** - Core architectural decisions that are **locked and cannot be changed**
- Static generation + PWA enhancement approach
- Technical stack specifications
- Feature scope (included vs forbidden)
- Complexity principles and constraints

### 🤖 [AI-SESSION-GUIDELINES.md](./AI-SESSION-GUIDELINES.md)
**BEHAVIORAL RULES** - How AI must operate during development
- Scope creep detection and prevention
- Verification-driven development requirements
- Complexity consciousness and simplicity-first principles
- Error handling and recovery protocols

### 📊 [CURRENT-PROJECT-STATE.md](./CURRENT-PROJECT-STATE.md)
**LIVING DOCUMENT** - Current status, updated after each AI session
- Implementation progress tracking
- Working vs non-working features
- Next priority tasks and blockers
- Complexity metrics and risk assessment

## Critical Rules

### For AI Development (UPDATED):
```yaml
BEFORE ANY CODING:
1. Read LESSONS-LEARNED-SYSTEM-V2.md (understand Menu-Driven approach)
2. Read CURRENT-PROJECT-STATE.md (understand status)
3. Read MVP-ARCHITECTURE-DECISIONS.md (understand scope)
4. Follow Menu-Driven process (propose options, don't decide)

DURING DEVELOPMENT:
- Translate Eric's business needs to technical options
- Present 2-3 clear implementation approaches
- Implement exactly what Eric chooses (no creativity)
- Stay within approved pattern library

AFTER DEVELOPMENT:  
- Update CURRENT-PROJECT-STATE.md
- Create verification instructions for Eric
- Document any new successful patterns
```

### Menu-Driven Process:
```yaml
✅ Eric describes business outcome needed
✅ AI proposes 2-3 technical implementation options  
✅ Eric chooses preferred option
✅ AI confirms implementation details
✅ Eric approves specific implementation
✅ AI implements exactly as approved (no additions)
```

---

**This documentation represents the institutional memory of the OneShot MVP project, including our breakthrough Menu-Driven Development discovery. The V2 system solves the fundamental problem of Eric controlling product direction without needing technical expertise.**

**ALL AI DEVELOPMENT MUST START BY READING LESSONS-LEARNED-SYSTEM-V2.md** 