# IMPLEMENTATION PATTERNS
**Created**: 2025-01-20  
**Status**: LIBRARY - Only these patterns allowed in Menu-Driven Development  
**Purpose**: Pre-approved implementation approaches to speed up development

## CORE CONCEPT
**All Menu-Driven Development choices must use these pre-tested patterns. No custom implementations.**

## PATTERN CATEGORIES

### **1. FORM PATTERNS**

#### **Pattern A: Basic Data Collection**
```yaml
Use Case: Athlete name, school, position, basic stats
Implementation: 
  - HTML form → JSON validation → Template generation
  - Fields: text, select, number inputs only
  - Client validation: required fields, format checking
  - Server validation: Zod schema validation
Code Size: ~150 lines total
Eric Verification: Fill form, see data display correctly
```

#### **Pattern B: Conditional Form Fields**
```yaml
Use Case: Position-specific stats (QB passing yards, RB rushing yards)
Implementation:
  - JavaScript show/hide based on position selection
  - JSON schema adapts to position type
  - Template conditionally renders stats
Code Size: ~200 lines total  
Eric Verification: Change position, see different stat fields
```

### **2. FILE UPLOAD PATTERNS**

#### **Pattern A: Single Photo Upload**
```yaml
Use Case: Profile headshot, action photo
Implementation:
  - Multer middleware for file handling
  - Image validation (JPEG/PNG, size limits)
  - File renamed to UUID + original extension
  - JSON stores filename reference
Code Size: ~100 lines total
Eric Verification: Upload photo, see it display in profile
```

#### **Pattern B: PDF Document Upload**
```yaml
Use Case: Transcript, recommendation letters
Implementation:
  - Same multer setup as photos
  - PDF validation and virus scanning
  - Generate download link in profile
  - JSON stores filename + original name
Code Size: ~120 lines total
Eric Verification: Upload PDF, click download link
```

### **3. PRIVACY PATTERNS**

#### **Pattern A: Profile-Level Privacy**
```yaml
Use Case: Public vs private athlete profiles
Implementation:
  - Boolean flag in JSON data
  - Template generation respects privacy setting
  - Private profiles show "Profile Not Public" page
  - QR codes work but show privacy message
Code Size: ~80 lines total
Eric Verification: Toggle privacy, scan QR code
```

#### **Pattern B: Field-Level Privacy**
```yaml
Use Case: Hide GPA, contact info from coaches
Implementation:
  - JSON object with field visibility flags
  - Template conditionally renders each field
  - Edit form has show/hide toggles
  - Public profile respects all settings
Code Size: ~150 lines total
Eric Verification: Hide GPA, confirm coach can't see it
```

### **4. STATIC GENERATION PATTERNS**

#### **Pattern A: Basic HTML Generation**
```yaml
Use Case: Convert JSON profile to static HTML page
Implementation:
  - Handlebars template with profile data
  - CSS inlined for mobile performance
  - Generated file saved to static/ directory
  - CDN URL returned to client
Code Size: ~100 lines total
Eric Verification: Create profile, visit generated URL
```

#### **Pattern B: QR Code Integration**
```yaml
Use Case: Generate QR codes for coach scanning
Implementation:
  - QRCode.js library generates SVG codes
  - QR contains profile static URL
  - QR image saved as PNG file
  - Profile page displays QR code
Code Size: ~60 lines total
Eric Verification: Scan QR with phone, reach profile
```

## MENU-DRIVEN DEVELOPMENT INTEGRATION

### **How Patterns Work with Choices**:

#### **Example Session**:
```yaml
Eric: "I want athletes to upload photos"

AI Proposes:
Option 1: Pattern A - Single photo upload (simpler)
Option 2: Pattern B - Multiple photos (more complex)
Option 3: Pattern A + basic gallery (medium complexity)

Eric Chooses: Option 1

AI Implements: Pattern A exactly as documented
- No creative additions
- No architectural changes  
- Standard verification approach
```

### **Pattern Constraints**:
```yaml
All patterns must:
- Fit within complexity budget (<2,000 lines total)
- Generate static HTML output
- Use JSON source of truth
- Be verifiable by Eric in 30 seconds
- Work on mobile devices
- Degrade gracefully if features fail
```

## AUTHENTICATION PATTERNS

### **Pattern A: Magic URL Generation**
```yaml
Use Case: No-password profile editing
Implementation:
  - Generate 32-character random token
  - Store token → profile mapping in JSON
  - Edit URLs: /edit/[token] 
  - Token validation on each request
Code Size: ~80 lines total
Eric Verification: Click edit link, reach edit form
```

### **Pattern B: Simple User Registration**
```yaml
Use Case: Athletes create accounts to manage profiles
Implementation:
  - Email + simple form (no password)
  - Send magic link to email address
  - Create user record with generated edit token
  - Link user → profile relationship
Code Size: ~150 lines total
Eric Verification: Register, get email, create profile
```

## ERROR HANDLING PATTERNS

### **Pattern A: Graceful Degradation**
```yaml
Use Case: Handle API failures without breaking profiles
Implementation:
  - Static profiles always accessible
  - Error.html fallback page for broken generation
  - API errors show user-friendly messages
  - Automatic retry for transient failures
Code Size: ~60 lines total
Eric Verification: Break API, confirm profiles still load
```

### **Pattern B: Input Validation**
```yaml
Use Case: Prevent bad data from breaking profile generation
Implementation:
  - Zod schemas for all form inputs
  - Client-side validation for immediate feedback
  - Server-side validation before saving
  - Clear error messages for users
Code Size: ~100 lines total
Eric Verification: Submit invalid data, see helpful errors
```

## VIDEO EMBEDDING PATTERNS

### **Pattern A: YouTube/Hudl Links**
```yaml
Use Case: Athletes share highlight videos
Implementation:
  - URL validation for supported platforms
  - Extract video ID from various URL formats
  - Generate responsive embed code
  - Template renders iframe with video
Code Size: ~90 lines total
Eric Verification: Add video URL, see video play in profile
```

## MOBILE OPTIMIZATION PATTERNS

### **Pattern A: Responsive Static Pages**
```yaml
Use Case: Profiles look good on all devices
Implementation:
  - Mobile-first CSS design
  - Viewport meta tags
  - Touch-friendly buttons and links
  - Fast loading times (<1 second)
Code Size: Built into templates
Eric Verification: View profile on phone, confirm usability
```

### **Pattern B: PWA Enhancement**
```yaml
Use Case: Install app on phone, offline access
Implementation:
  - Web app manifest
  - Service worker for offline caching
  - Install prompts for iOS/Android
  - Cached static profiles work offline
Code Size: ~200 lines total
Eric Verification: Install app, use offline
```

## PATTERN SELECTION GUIDELINES

### **For Menu-Driven Development**:

#### **Complexity Level Assessment**:
```yaml
Low Complexity (Pattern A): 
- Single feature focus
- Minimal code interaction
- Easy to verify
- Fast implementation

Medium Complexity (Pattern B):
- Multiple features working together
- Some configuration required
- Clear verification steps
- Moderate implementation time

Never High Complexity:
- Menu-Driven Development avoids complex patterns
- Break complex needs into multiple simple patterns
```

#### **Pattern Combination Rules**:
```yaml
Compatible Combinations:
- Form Pattern A + File Upload Pattern A
- Privacy Pattern A + Static Generation Pattern A
- Auth Pattern A + Error Handling Pattern A

Incompatible Combinations:
- Multiple file upload patterns (complexity explosion)
- Complex form + complex privacy (verification impossible)
```

## PATTERN TESTING PROTOCOL

### **Before Adding New Patterns**:
```yaml
Requirements:
1. Pattern must be implementable in <200 lines
2. Eric can verify functionality in 30 seconds
3. Pattern works on mobile devices
4. Pattern handles common error cases
5. Pattern fits existing architecture
```

### **Pattern Approval Process**:
```yaml
1. Document pattern clearly
2. Implement test version
3. Eric verifies with 4 questions
4. Add to approved pattern library
5. Mark as available for Menu-Driven Development
```

## HANDLING REQUESTS OUTSIDE PATTERN LIBRARY

### **When Eric's Request Doesn't Fit Any Pattern**:

#### **AI Response Protocol**:
```yaml
AI: "This request doesn't match our existing patterns. I can offer:

Option 1: Break into smaller pieces that DO fit existing patterns
- [Specific breakdown of request into known patterns]

Option 2: Create new pattern based on your request
- Implement minimal version as new Pattern [X]
- Test with you before adding to library
- Use for similar future requests

Option 3: Simplify request to fit closest existing pattern
- [Modified version that fits existing Pattern Y]

Which approach would you prefer?"
```

#### **New Pattern Creation Process**:
```yaml
If Eric chooses Option 2:

1. AI implements minimal version (≤150 lines)
2. Eric tests with 4 questions
3. If successful: Add to pattern library as Pattern [Letter]
4. If issues: Revise and test again
5. Maximum 2 revisions before falling back to Option 1 or 3

New Pattern Requirements:
- Must be generically reusable
- Must fit architectural constraints
- Must be Eric-verifiable
- Must work on mobile
```

#### **Pattern Combination Rules**:
```yaml
For Option 1 (Break into pieces):
- Maximum 2 existing patterns combined per session
- Each pattern must be independently verifiable
- Combined complexity must stay under session budget
- If too complex: Split across multiple sessions
```

## EMERGENCY PATTERN EXPANSION

### **If Pattern Library Proves Insufficient**:
```yaml
Expansion Protocol:
1. Identify most frequently needed missing patterns
2. Create batch of 3-4 new patterns
3. Eric approves each pattern individually
4. Add to library for future use
5. Update pattern combination rules

Expansion Triggers:
- 3+ requests requiring same missing pattern
- Core MVP feature impossible with existing patterns
- User feedback indicating pattern gaps
```

## RAPID PATTERN CREATION WORKFLOW

### **Fast-Track Pattern Development**
```yaml
When Eric's Request Needs New Pattern:

Immediate Response (Same Session):
1. AI implements minimal version in <90 minutes
2. Eric tests immediately with 4 questions
3. If successful: becomes Pattern [Next Letter]
4. If issues: revert to existing pattern combination

Fast-Track Requirements:
- ≤100 lines of code
- Uses existing architectural patterns
- Single focused functionality
- No complex pattern interactions
```

### **Most Likely Missing Patterns (Prediction)**
```yaml
Based on MVP needs, we'll probably need:

Pattern I: Multi-Step Forms
- Use Case: Profile creation wizard
- Likely needed when: Basic form becomes too complex
- Estimated complexity: ~120 lines

Pattern J: Conditional Display Logic
- Use Case: Show different info based on position/sport
- Likely needed when: Static templates too rigid
- Estimated complexity: ~80 lines

Pattern K: Bulk Data Import
- Use Case: Import stats from spreadsheet
- Likely needed when: Manual entry too tedious
- Estimated complexity: ~150 lines

Pattern L: Social Sharing
- Use Case: Share profile on social media
- Likely needed when: Athletes want wider reach
- Estimated complexity: ~60 lines

Pattern M: Data Export
- Use Case: Download profile as PDF/resume
- Likely needed when: Coaches want offline access
- Estimated complexity: ~100 lines
```

### **Pattern Creation Time Budgets**
```yaml
For Rapid Pattern Creation:

Simple Pattern (≤80 lines): 1 hour max
- Single functionality
- No complex integrations
- Eric can verify immediately

Medium Pattern (≤120 lines): 2 hours max
- Multiple related functions
- Some integration complexity
- Eric verification + minor adjustments

Complex Pattern (≤150 lines): 3 hours max
- Advanced functionality
- Multiple integration points
- Eric verification + testing + refinements

Over 150 lines: Not a pattern, break it down
```

---

**This pattern library enables rapid Menu-Driven Development while maintaining quality and verifiability.** 