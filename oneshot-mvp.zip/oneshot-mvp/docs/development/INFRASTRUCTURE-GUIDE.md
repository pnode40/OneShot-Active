# INFRASTRUCTURE GUIDE
**Created**: 2025-01-20  
**Status**: REQUIRED - Production-ready deployment and monitoring  
**Purpose**: Ensure reliable, scalable infrastructure for MVP and beyond

## DEPLOYMENT ARCHITECTURE

### **Production Stack**
```yaml
Frontend: Static files hosted on Vercel/Netlify CDN
Backend API: Express.js on Railway/Render
Database: PostgreSQL (Supabase/Railway)
File Storage: Cloudinary/AWS S3
Monitoring: Sentry + Uptime Robot
Analytics: Simple Analytics (privacy-focused)
```

### **Environment Structure**
```yaml
Development: Local development with TypeScript
Staging: Full production replica for testing
Production: Live environment with monitoring
```

## DATABASE SETUP

### **Migration from JSON to PostgreSQL**
```sql
-- User accounts table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  edit_token VARCHAR(32) UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Athlete profiles table
CREATE TABLE profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  slug VARCHAR(100) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  school VARCHAR(255),
  position VARCHAR(100),
  year VARCHAR(20),
  gpa DECIMAL(3,2),
  is_public BOOLEAN DEFAULT false,
  profile_data JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- File uploads table
CREATE TABLE uploads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID REFERENCES profiles(id),
  file_type VARCHAR(50),
  original_name VARCHAR(255),
  stored_name VARCHAR(255),
  file_size INTEGER,
  mime_type VARCHAR(100),
  uploaded_at TIMESTAMP DEFAULT NOW()
);
```

### **Data Migration Strategy**
```yaml
Phase 1: Dual write (JSON + DB) for new data
Phase 2: Migrate existing JSON data to database
Phase 3: Remove JSON dependency
Phase 4: Optimize database performance
```

## MONITORING & ANALYTICS

### **Error Tracking (Sentry)**
```javascript
// Error monitoring setup
import * as Sentry from '@sentry/node';

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
  tracesSampleRate: 0.1,
});

// Custom error tracking for our patterns
export const trackPatternError = (pattern: string, error: Error) => {
  Sentry.captureException(error, {
    tags: {
      pattern,
      feature: 'mvp',
    },
  });
};
```

### **Performance Monitoring**
```yaml
Core Web Vitals Tracking:
- Largest Contentful Paint (LCP): <2.5s
- First Input Delay (FID): <100ms  
- Cumulative Layout Shift (CLS): <0.1

Custom Metrics:
- QR code scan success rate
- Profile creation completion rate
- File upload success rate
- Mobile vs desktop usage
```

### **Usage Analytics**
```javascript
// Privacy-focused analytics
import { track } from '@vercel/analytics';

export const trackUserAction = (action: string, properties?: Record<string, any>) => {
  track(action, {
    ...properties,
    timestamp: new Date().toISOString(),
  });
};

// Usage examples
trackUserAction('profile_created', { position: 'QB' });
trackUserAction('qr_code_scanned', { device: 'mobile' });
```

## DEPLOYMENT PROCEDURES

### **Staging Deployment**
```bash
# Automated via GitHub Actions
npm run validate          # Lint, test, pattern check
npm run build            # TypeScript compilation
npm run deploy:staging   # Deploy to staging environment

# Manual verification
curl https://staging.oneshotrecruits.com/health
npm run test:mobile      # Run mobile compatibility tests
```

### **Production Deployment**
```bash
# Only from main branch, after staging verification
npm run validate
npm run build
npm run deploy:prod

# Post-deployment verification
npm run test:smoke       # Basic functionality check
npm run monitor:start    # Enable monitoring alerts
```

### **Rollback Procedures**
```bash
# Immediate rollback
npm run deploy:rollback

# Database rollback (if needed)
npm run db:rollback

# Monitoring check
npm run monitor:check
```

## SECURITY CONFIGURATION

### **Environment Variables**
```yaml
# Required for all environments
NODE_ENV=production
DATABASE_URL=postgresql://...
SENTRY_DSN=https://...

# File upload security
MAX_FILE_SIZE=10MB
ALLOWED_FILE_TYPES=jpg,png,pdf
UPLOAD_VIRUS_SCAN=true

# Authentication
JWT_SECRET=...
MAGIC_URL_EXPIRY=24h

# Third-party services
CLOUDINARY_URL=...
SENDGRID_API_KEY=...
```

### **Security Headers**
```javascript
// Helmet.js configuration
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
    },
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true,
  },
}));
```

## BACKUP & RECOVERY

### **Database Backups**
```yaml
Automated Backups:
- Daily full backup to S3
- Hourly incremental backups
- 30-day retention policy
- Cross-region replication

Recovery Testing:
- Monthly backup restore test
- Documented recovery procedures
- RTO: 1 hour, RPO: 1 hour
```

### **File Storage Backups**
```yaml
User Uploads:
- Automatic replication to backup storage
- Versioning enabled for accidental deletions
- 90-day retention for deleted files

Static Files:
- Git-based version control
- CDN automatic caching
- Build artifact storage
```

## SCALING CONSIDERATIONS

### **Performance Optimization**
```yaml
CDN Configuration:
- Global edge caching for static profiles
- Image optimization and resizing
- Gzip compression for all assets

Database Optimization:
- Indexed queries for profile lookup
- Connection pooling
- Read replicas for heavy queries

API Optimization:
- Response caching where appropriate
- Rate limiting for API endpoints
- Efficient JSON serialization
```

### **Load Testing**
```javascript
// k6 load testing script
import http from 'k6/http';
import { check } from 'k6';

export let options = {
  stages: [
    { duration: '2m', target: 100 }, // Ramp up
    { duration: '5m', target: 100 }, // Stay at 100 users
    { duration: '2m', target: 0 },   // Ramp down
  ],
};

export default function() {
  let response = http.get('https://oneshotrecruits.com/api/health');
  check(response, {
    'status is 200': (r) => r.status === 200,
    'response time < 500ms': (r) => r.timings.duration < 500,
  });
}
```

## INCIDENT RESPONSE

### **Alert Configuration**
```yaml
Critical Alerts (Page immediately):
- Server down (5xx errors >5% for 2 minutes)
- Database connection lost
- File upload failures >20%
- QR code generation failures >10%

Warning Alerts (Slack notification):
- Response time >2 seconds
- Error rate >1%
- Disk space >80%
- Memory usage >85%
```

### **Incident Procedures**
```yaml
1. Immediate Response (0-5 minutes):
   - Acknowledge alert
   - Check system status
   - Implement quick fix if available

2. Investigation (5-30 minutes):
   - Identify root cause
   - Document timeline
   - Communicate to stakeholders

3. Resolution (30+ minutes):
   - Implement permanent fix
   - Verify resolution
   - Update monitoring/alerts

4. Post-Incident (24-48 hours):
   - Write incident report
   - Update documentation
   - Implement preventive measures
```

---

**This infrastructure setup ensures reliable, scalable, and maintainable deployment for the OneShot MVP and future growth.** 