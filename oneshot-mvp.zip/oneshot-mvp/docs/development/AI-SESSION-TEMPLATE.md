# AI SESSION TEMPLATE
**Use this template to start every AI development session**

## 🚨 MANDATORY PRE-SESSION CHECKPOINT

**COPY-PASTE AND RUN THIS COMMAND FIRST:**
```bash
npm run session-start
```

### **Visual Status Check:**
```
🔴 STOP: Systems not verified - DO NOT PROCEED
🟡 WARNING: Some systems need attention - proceed with caution  
🟢 GO: All systems operational - safe to proceed
```

### **If You See 🔴 or 🟡:**
1. **STOP** immediately
2. Run: `npm run feature-complete`
3. Wait for all systems to pass
4. Re-run: `npm run session-start`
5. Only proceed when you see **🟢**

## 📋 SESSION CHECKLIST

Before starting ANY new feature work:

- [ ] ✅ Checkpoint verification passed
- [ ] 📓 Changelog up to date
- [ ] 📚 Documentation synchronized  
- [ ] 🧠 AI context current
- [ ] 🧪 Tests passing with coverage noted
- [ ] 🔐 Pattern constraints enforced
- [ ] 📊 System health: HEALTHY

## 🎯 ACCOUNTABILITY RULES

**Never bypass these rules:**
1. **No work without green checkpoint**
2. **Run `npm run feature-complete` after every feature**
3. **Use this template for every session**
4. **If tempted to skip: That's exactly when you need it most**

## 🚫 FORBIDDEN PHRASES

These indicate accountability decay:
- ❌ "We don't need to run that this time"
- ❌ "The system is probably fine"  
- ❌ "We're in a hurry, let's skip it"
- ❌ "That takes too long"

**Response**: Run the checkpoint anyway!

---

**Remember: 30 seconds of verification prevents hours of debugging drift.** 