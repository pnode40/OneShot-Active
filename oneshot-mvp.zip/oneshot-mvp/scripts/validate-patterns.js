#!/usr/bin/env node

/**
 * Pattern Validation Script
 * Ensures code follows documented implementation patterns
 */

const fs = require('fs');
const path = require('path');

class PatternValidator {
  constructor() {
    this.errors = [];
    this.warnings = [];
  }

  validateFileStructure() {
    const requiredDirs = ['src/server', 'src/templates', 'src/types'];
    const requiredFiles = [
      'src/server/app.ts',
      'src/server/generator.ts',
      'src/server/validator.ts',
      'src/types/profile.ts'
    ];

    requiredDirs.forEach(dir => {
      if (!fs.existsSync(dir)) {
        this.errors.push(`Missing required directory: ${dir}`);
      }
    });

    requiredFiles.forEach(file => {
      if (!fs.existsSync(file)) {
        this.warnings.push(`Expected file not found: ${file}`);
      }
    });
  }

  validateNamingConventions() {
    // Check for consistent naming patterns
    const srcFiles = this.getAllFiles('src', ['.ts', '.js']);
    
    srcFiles.forEach(file => {
      const content = fs.readFileSync(file, 'utf8');
      
      // Check for consistent variable naming
      if (content.includes('gpaScore') && content.includes('gpa_score')) {
        this.errors.push(`Inconsistent naming in ${file}: mix of camelCase and snake_case`);
      }
      
      // Check for proper error handling
      if (content.includes('try {') && !content.includes('catch')) {
        this.warnings.push(`Try block without catch in ${file}`);
      }
    });
  }

  validateZodSchemas() {
    // Ensure all form inputs use Zod validation
    const serverFiles = this.getAllFiles('src/server', ['.ts']);
    
    serverFiles.forEach(file => {
      const content = fs.readFileSync(file, 'utf8');
      
      // If file handles user input, it should use Zod
      if (content.includes('req.body') && !content.includes('z.')) {
        this.warnings.push(`${file} processes user input but doesn't use Zod validation`);
      }
    });
  }

  validateComplexityBudget() {
    const allFiles = this.getAllFiles('src', ['.ts', '.js']);
    let totalLines = 0;
    const MAX_LINES = 2000;
    
    allFiles.forEach(file => {
      const content = fs.readFileSync(file, 'utf8');
      const lines = content.split('\n').filter(line => line.trim() !== '').length;
      totalLines += lines;
      
      if (lines > 200) {
        this.warnings.push(`${file} has ${lines} lines (pattern max: 200)`);
      }
    });
    
    if (totalLines > MAX_LINES) {
      this.errors.push(`Total codebase: ${totalLines} lines (budget: ${MAX_LINES})`);
    }
    
    console.log(`📊 Complexity: ${totalLines}/${MAX_LINES} lines (${Math.round(totalLines/MAX_LINES*100)}%)`);
  }

  getAllFiles(dir, extensions) {
    const files = [];
    
    if (!fs.existsSync(dir)) return files;
    
    const items = fs.readdirSync(dir);
    
    items.forEach(item => {
      const fullPath = path.join(dir, item);
      const stat = fs.statSync(fullPath);
      
      if (stat.isDirectory()) {
        files.push(...this.getAllFiles(fullPath, extensions));
      } else if (extensions.some(ext => item.endsWith(ext))) {
        files.push(fullPath);
      }
    });
    
    return files;
  }

  run() {
    console.log('🔍 Validating implementation patterns...\n');
    
    this.validateFileStructure();
    this.validateNamingConventions();
    this.validateZodSchemas();
    this.validateComplexityBudget();
    
    // Report results
    if (this.errors.length === 0 && this.warnings.length === 0) {
      console.log('✅ All pattern validations passed!');
      return true;
    }
    
    if (this.errors.length > 0) {
      console.log('\n🚨 ERRORS:');
      this.errors.forEach(error => console.log(`  ❌ ${error}`));
    }
    
    if (this.warnings.length > 0) {
      console.log('\n⚠️  WARNINGS:');
      this.warnings.forEach(warning => console.log(`  ⚠️  ${warning}`));
    }
    
    return this.errors.length === 0;
  }
}

// Run validation
const validator = new PatternValidator();
const success = validator.run();

process.exit(success ? 0 : 1); 