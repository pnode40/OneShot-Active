#!/usr/bin/env node

/**
 * System Health Check - Anti-Drift Validation
 * Runs after every feature to ensure system integrity
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

class SystemHealthChecker {
  constructor() {
    this.errors = [];
    this.warnings = [];
    this.metrics = {};
  }

  async runFullHealthCheck() {
    console.log('🔄 SYSTEM RELOAD - Comprehensive Health Check\n');
    
    // 1. Pattern Library Validation
    await this.validatePatternLibrary();
    
    // 2. Documentation Synchronization
    await this.validateDocumentationSync();
    
    // 3. Code Quality Metrics
    await this.validateQualityMetrics();
    
    // 4. Architecture Compliance
    await this.validateArchitectureCompliance();
    
    // 5. Feature Consistency
    await this.validateFeatureConsistency();
    
    // 6. AI Context Validation
    await this.validateAIContext();
    
    return this.generateHealthReport();
  }

  async validatePatternLibrary() {
    console.log('📋 Validating Pattern Library...');
    
    // Check if implemented patterns match documented patterns
    const patterns = await this.getImplementedPatterns();
    const documentedPatterns = await this.getDocumentedPatterns();
    
    // Pattern drift detection
    patterns.forEach(pattern => {
      if (!documentedPatterns.includes(pattern.name)) {
        this.warnings.push(`Undocumented pattern in use: ${pattern.name}`);
      }
      
      if (pattern.complexity > pattern.budgetedComplexity * 1.5) {
        this.errors.push(`Pattern ${pattern.name} exceeds complexity budget: ${pattern.complexity}/${pattern.budgetedComplexity}`);
      }
    });
    
    // Check for pattern consistency across features
    const inconsistencies = await this.checkPatternConsistency();
    this.warnings.push(...inconsistencies);
    
    this.metrics.patternsImplemented = patterns.length;
    this.metrics.patternsDocumented = documentedPatterns.length;
  }

  async validateDocumentationSync() {
    console.log('📚 Validating Documentation Synchronization...');
    
    // Check if README reflects current features
    const readmeFeatures = await this.extractFeaturesFromReadme();
    const implementedFeatures = await this.getImplementedFeatures();
    
    implementedFeatures.forEach(feature => {
      if (!readmeFeatures.includes(feature)) {
        this.warnings.push(`Feature ${feature} implemented but not documented in README`);
      }
    });
    
    // Check if AI guidelines reflect current patterns
    const aiGuidelines = await this.getAIGuidelines();
    const currentPatterns = await this.getImplementedPatterns();
    
    currentPatterns.forEach(pattern => {
      if (!aiGuidelines.includes(pattern.name)) {
        this.warnings.push(`Pattern ${pattern.name} not reflected in AI guidelines`);
      }
    });
    
    // Check architecture decisions alignment
    const architectureDoc = await this.getArchitectureDecisions();
    const actualArchitecture = await this.analyzeActualArchitecture();
    
    if (!this.architecturesMatch(architectureDoc, actualArchitecture)) {
      this.errors.push('Architecture documentation does not match implementation');
    }
  }

  async validateQualityMetrics() {
    console.log('📊 Validating Quality Metrics...');
    
    // Complexity budget tracking
    const totalComplexity = await this.calculateTotalComplexity();
    const complexityBudget = 2000;
    
    this.metrics.complexity = {
      current: totalComplexity,
      budget: complexityBudget,
      percentage: Math.round((totalComplexity / complexityBudget) * 100)
    };
    
    if (totalComplexity > complexityBudget) {
      this.errors.push(`Complexity budget exceeded: ${totalComplexity}/${complexityBudget} lines`);
    }
    
    // Test coverage validation
    const testCoverage = await this.getTestCoverage();
    this.metrics.testCoverage = testCoverage;
    
    if (testCoverage < 80) {
      this.warnings.push(`Test coverage below threshold: ${testCoverage}%`);
    }
    
    // Pattern compliance score
    const complianceScore = await this.calculatePatternCompliance();
    this.metrics.patternCompliance = complianceScore;
    
    if (complianceScore < 90) {
      this.warnings.push(`Pattern compliance below threshold: ${complianceScore}%`);
    }
  }

  async validateArchitectureCompliance() {
    console.log('🏗️ Validating Architecture Compliance...');
    
    // Static generation compliance
    const staticGenCompliance = await this.checkStaticGenerationCompliance();
    if (!staticGenCompliance.compliant) {
      this.warnings.push(`Static generation violations: ${staticGenCompliance.violations.join(', ')}`);
    }
    
    // JSON source of truth validation
    const jsonCompliance = await this.checkJSONSourceCompliance();
    if (!jsonCompliance.compliant) {
      this.errors.push(`JSON source of truth violations: ${jsonCompliance.violations.join(', ')}`);
    }
    
    // Magic URL authentication check
    const authCompliance = await this.checkAuthenticationCompliance();
    if (!authCompliance.compliant) {
      this.errors.push(`Authentication violations: ${authCompliance.violations.join(', ')}`);
    }
  }

  async validateFeatureConsistency() {
    console.log('🔗 Validating Feature Consistency...');
    
    // Cross-feature naming consistency
    const namingConsistency = await this.checkNamingConsistency();
    this.warnings.push(...namingConsistency.violations);
    
    // Validation consistency
    const validationConsistency = await this.checkValidationConsistency();
    this.warnings.push(...validationConsistency.violations);
    
    // Error handling consistency
    const errorHandlingConsistency = await this.checkErrorHandlingConsistency();
    this.warnings.push(...errorHandlingConsistency.violations);
    
    // Mobile optimization consistency
    const mobileConsistency = await this.checkMobileOptimizationConsistency();
    this.warnings.push(...mobileConsistency.violations);
  }

  async validateAIContext() {
    console.log('🤖 Validating AI Context Currency...');
    
    // Check if AI guidelines reflect current system state
    const contextCurrency = await this.checkAIContextCurrency();
    
    if (contextCurrency.outdatedDocs.length > 0) {
      this.warnings.push(`Outdated AI context documents: ${contextCurrency.outdatedDocs.join(', ')}`);
    }
    
    // Verify pattern library is complete
    const patternLibraryComplete = await this.checkPatternLibraryCompleteness();
    if (!patternLibraryComplete.complete) {
      this.warnings.push(`Pattern library gaps: ${patternLibraryComplete.missingPatterns.join(', ')}`);
    }
    
    // Check verification system alignment
    const verificationAlignment = await this.checkVerificationSystemAlignment();
    if (!verificationAlignment.aligned) {
      this.warnings.push(`Verification system misalignment: ${verificationAlignment.issues.join(', ')}`);
    }
    
    // Check changelog currency
    await this.validateChangelogCurrency();
  }

  async validateChangelogCurrency() {
    console.log('📝 Validating Changelog Currency...');
    
    const changelogPath = 'CHANGE-LOG.md';
    
    if (!fs.existsSync(changelogPath)) {
      this.warnings.push('CHANGE-LOG.md does not exist - should be auto-generated');
      return;
    }
    
    try {
      // Check if there are commits since last changelog entry
      const lastChangelogCommit = this.getLastChangelogCommit();
      const commitsSinceChangelog = this.getCommitsSince(lastChangelogCommit);
      
      if (commitsSinceChangelog.length > 0) {
        this.warnings.push(`${commitsSinceChangelog.length} commits since last changelog entry`);
      }
      
      // Check changelog format
      const changelogContent = fs.readFileSync(changelogPath, 'utf8');
      
      if (!changelogContent.includes('## [')) {
        this.warnings.push('Changelog format invalid - missing version entries');
      }
      
      if (!changelogContent.includes('### ✨ Features')) {
        this.warnings.push('Changelog missing standard sections');
      }
      
    } catch (error) {
      this.warnings.push('Could not validate changelog currency');
    }
  }

  getLastChangelogCommit() {
    try {
      return execSync('git log -1 --format="%H" -- CHANGE-LOG.md', { encoding: 'utf8' }).trim();
    } catch (error) {
      return null;
    }
  }

  getCommitsSince(commit) {
    if (!commit) return [];
    
    try {
      const commits = execSync(`git log ${commit}..HEAD --oneline`, { encoding: 'utf8' });
      return commits.split('\n').filter(line => line.trim());
    } catch (error) {
      return [];
    }
  }

  generateHealthReport() {
    const status = this.errors.length === 0 ? 'HEALTHY' : 'CRITICAL';
    const warningCount = this.warnings.length;
    
    console.log('\n' + '='.repeat(60));
    console.log(`🏥 SYSTEM HEALTH REPORT - Status: ${status}`);
    console.log('='.repeat(60));
    
    // Metrics summary
    console.log('\n📊 KEY METRICS:');
    console.log(`Complexity: ${this.metrics.complexity?.current || 0}/${this.metrics.complexity?.budget || 2000} lines (${this.metrics.complexity?.percentage || 0}%)`);
    console.log(`Test Coverage: ${this.metrics.testCoverage || 0}%`);
    console.log(`Pattern Compliance: ${this.metrics.patternCompliance || 0}%`);
    console.log(`Patterns Implemented: ${this.metrics.patternsImplemented || 0}`);
    
    // Issues summary
    if (this.errors.length > 0) {
      console.log('\n🚨 CRITICAL ISSUES:');
      this.errors.forEach(error => console.log(`  ❌ ${error}`));
    }
    
    if (this.warnings.length > 0) {
      console.log('\n⚠️  WARNINGS:');
      this.warnings.forEach(warning => console.log(`  ⚠️  ${warning}`));
    }
    
    if (this.errors.length === 0 && this.warnings.length === 0) {
      console.log('\n✅ ALL SYSTEMS OPERATIONAL');
      console.log('System integrity maintained, ready for next feature.');
    }
    
    // Recommendations
    console.log('\n🎯 RECOMMENDATIONS:');
    if (this.errors.length > 0) {
      console.log('  🔥 Address critical issues before proceeding');
    }
    if (warningCount > 5) {
      console.log('  📋 Consider pattern library refresh session');
    }
    if (this.metrics.complexity?.percentage > 80) {
      console.log('  ⚖️  Approaching complexity budget, plan optimization');
    }
    
    console.log('\n' + '='.repeat(60));
    
    return {
      status,
      errors: this.errors,
      warnings: this.warnings,
      metrics: this.metrics,
      healthy: this.errors.length === 0
    };
  }

  // Helper methods (implementation would be detailed)
  async getImplementedPatterns() {
    // Analyze codebase to identify patterns in use
    return [];
  }

  async getDocumentedPatterns() {
    // Parse IMPLEMENTATION-PATTERNS.md
    return [];
  }

  async calculateTotalComplexity() {
    // Count lines of code
    return 0;
  }

  async getTestCoverage() {
    // Get coverage from Jest
    return 85;
  }

  async calculatePatternCompliance() {
    // Analyze pattern adherence
    return 95;
  }

  // ... other helper methods
}

// Run health check
async function runSystemHealthCheck() {
  const checker = new SystemHealthChecker();
  const report = await checker.runFullHealthCheck();
  
  // Save report for tracking
  const timestamp = new Date().toISOString().split('T')[0];
  fs.writeFileSync(
    `docs/health-reports/health-report-${timestamp}.json`,
    JSON.stringify(report, null, 2)
  );
  
  process.exit(report.healthy ? 0 : 1);
}

if (require.main === module) {
  runSystemHealthCheck().catch(console.error);
}

module.exports = { SystemHealthChecker }; 