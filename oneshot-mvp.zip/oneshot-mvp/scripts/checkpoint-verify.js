#!/usr/bin/env node

/**
 * Checkpoint Verification Script
 * Validates that all anti-drift systems have been properly executed
 */

const fs = require('fs');
const path = require('path');

class CheckpointVerifier {
  constructor() {
    this.failures = [];
    this.warnings = [];
    this.status = {
      reloadExecuted: false,
      changelogUpdated: false,
      docsSync: false,
      aiContextFresh: false,
      testsExecuted: false,
      patternsEnforced: false,
      systemHealthy: false
    };
  }

  async verifyCheckpoint() {
    console.log('🚨 CHECKPOINT VERIFICATION - Validating Anti-Drift Systems\n');
    
    // 1. Verify reload routine was executed
    await this.verifyReloadExecution();
    
    // 2. Verify changelog was updated
    await this.verifyChangelogUpdate();
    
    // 3. Verify documentation sync
    await this.verifyDocumentationSync();
    
    // 4. Verify AI context freshness
    await this.verifyAIContextFresh();
    
    // 5. Verify tests were executed
    await this.verifyTestExecution();
    
    // 6. Verify pattern enforcement
    await this.verifyPatternEnforcement();
    
    // 7. Verify system health
    await this.verifySystemHealth();
    
    return this.generateReport();
  }

  async verifyReloadExecution() {
    console.log('🔄 Checking reload routine execution...');
    
    // Check if health report exists and is recent
    const healthReportDir = 'docs/health-reports';
    if (!fs.existsSync(healthReportDir)) {
      this.failures.push('Health reports directory does not exist - reload not executed');
      return;
    }
    
    const today = new Date().toISOString().split('T')[0];
    const todayReport = path.join(healthReportDir, `health-report-${today}.json`);
    
    if (!fs.existsSync(todayReport)) {
      this.failures.push('No health report for today - reload routine not executed');
    } else {
      this.status.reloadExecuted = true;
      console.log('  ✅ Reload routine executed today');
    }
  }

  async verifyChangelogUpdate() {
    console.log('📓 Checking changelog update...');
    
    if (!fs.existsSync('CHANGE-LOG.md')) {
      this.failures.push('CHANGE-LOG.md does not exist');
      return;
    }
    
    const changelog = fs.readFileSync('CHANGE-LOG.md', 'utf8');
    const today = new Date().toISOString().split('T')[0];
    
    if (!changelog.includes(today)) {
      this.failures.push(`Changelog not updated today (${today})`);
    } else {
      this.status.changelogUpdated = true;
      console.log('  ✅ Changelog updated today');
    }
  }

  async verifyDocumentationSync() {
    console.log('📚 Checking documentation sync...');
    
    // Check if META-Doc-Index.json is recent
    const indexPath = 'docs/META-Doc-Index.json';
    if (!fs.existsSync(indexPath)) {
      this.warnings.push('Documentation index missing');
      return;
    }
    
    const indexStat = fs.statSync(indexPath);
    const lastModified = indexStat.mtime;
    const hoursAgo = (Date.now() - lastModified.getTime()) / (1000 * 60 * 60);
    
    if (hoursAgo > 24) {
      this.warnings.push('Documentation index not updated in 24 hours');
    } else {
      this.status.docsSync = true;
      console.log('  ✅ Documentation synchronized');
    }
  }

  async verifyAIContextFresh() {
    console.log('🧠 Checking AI context freshness...');
    
    const contextPath = 'docs/development/AI-CURRENT-CONTEXT.md';
    if (!fs.existsSync(contextPath)) {
      this.failures.push('AI context file missing');
      return;
    }
    
    const contextContent = fs.readFileSync(contextPath, 'utf8');
    const today = new Date().toISOString().split('T')[0];
    
    if (!contextContent.includes(today.substring(0, 7))) { // Check for year-month
      this.warnings.push('AI context may not be current');
    } else {
      this.status.aiContextFresh = true;
      console.log('  ✅ AI context refreshed');
    }
  }

  async verifyTestExecution() {
    console.log('🧪 Checking test execution...');
    
    // Check if coverage directory exists (indicates tests were run)
    if (fs.existsSync('coverage')) {
      const coverageStat = fs.statSync('coverage');
      const hoursAgo = (Date.now() - coverageStat.mtime.getTime()) / (1000 * 60 * 60);
      
      if (hoursAgo > 24) {
        this.warnings.push('Tests not run in 24 hours');
      } else {
        this.status.testsExecuted = true;
        console.log('  ✅ Tests executed recently');
      }
    } else {
      this.warnings.push('No test coverage data found');
    }
  }

  async verifyPatternEnforcement() {
    console.log('🔐 Checking pattern enforcement...');
    
    // Check if pattern validation was run (basic check)
    if (this.status.reloadExecuted) {
      this.status.patternsEnforced = true;
      console.log('  ✅ Pattern enforcement validated');
    } else {
      this.failures.push('Pattern enforcement not verified - reload not executed');
    }
  }

  async verifySystemHealth() {
    console.log('📊 Checking system health status...');
    
    const today = new Date().toISOString().split('T')[0];
    const healthReportPath = `docs/health-reports/health-report-${today}.json`;
    
    if (!fs.existsSync(healthReportPath)) {
      this.failures.push('Current health report not found');
      return;
    }
    
    try {
      const healthReport = JSON.parse(fs.readFileSync(healthReportPath, 'utf8'));
      
      if (healthReport.healthy) {
        this.status.systemHealthy = true;
        console.log('  ✅ System health: HEALTHY');
      } else {
        this.failures.push(`System health: CRITICAL (${healthReport.errors.length} errors)`);
      }
    } catch (error) {
      this.warnings.push('Could not parse health report');
    }
  }

  generateReport() {
    const passedChecks = Object.values(this.status).filter(Boolean).length;
    const totalChecks = Object.keys(this.status).length;
    const passed = this.failures.length === 0;
    
    // Visual status indicator
    let statusIndicator = '🔴 STOP';
    let statusMessage = 'Systems not verified - DO NOT PROCEED';
    
    if (passed && this.warnings.length === 0) {
      statusIndicator = '🟢 GO';
      statusMessage = 'All systems operational - safe to proceed';
    } else if (passed) {
      statusIndicator = '🟡 WARNING';
      statusMessage = 'Some systems need attention - proceed with caution';
    }
    
    console.log('\n' + '='.repeat(60));
    console.log(`🚨 CHECKPOINT VERIFICATION REPORT`);
    console.log('='.repeat(60));
    
    console.log(`\n${statusIndicator}: ${statusMessage}`);
    console.log(`📊 SUMMARY: ${passedChecks}/${totalChecks} checks passed\n`);
    
    // Status breakdown
    console.log('📋 CHECKPOINT STATUS:');
    console.log(`1. Reload routine: ${this.status.reloadExecuted ? '✅' : '❌'}`);
    console.log(`2. Changelog updated: ${this.status.changelogUpdated ? '✅' : '❌'}`);
    console.log(`3. Documentation synced: ${this.status.docsSync ? '✅' : '⚠️'}`);
    console.log(`4. AI context fresh: ${this.status.aiContextFresh ? '✅' : '⚠️'}`);
    console.log(`5. Tests executed: ${this.status.testsExecuted ? '✅' : '⚠️'}`);
    console.log(`6. Patterns enforced: ${this.status.patternsEnforced ? '✅' : '❌'}`);
    console.log(`7. System healthy: ${this.status.systemHealthy ? '✅' : '❌'}`);
    
    if (this.failures.length > 0) {
      console.log('\n🚨 CRITICAL FAILURES:');
      this.failures.forEach(failure => console.log(`  ❌ ${failure}`));
      console.log('\n🛑 DO NOT PROCEED - Run `npm run feature-complete` first');
      console.log('🔧 Quick fix: npm run pre-session');
    }
    
    if (this.warnings.length > 0) {
      console.log('\n⚠️  WARNINGS:');
      this.warnings.forEach(warning => console.log(`  ⚠️  ${warning}`));
    }
    
    if (passed && this.warnings.length === 0) {
      console.log('\n✅ ALL CHECKPOINT ITEMS VERIFIED');
      console.log('🎯 Anti-drift systems are operational. Safe to proceed.');
    } else if (passed) {
      console.log('\n✅ CHECKPOINT PASSED (with warnings)');
      console.log('🎯 Safe to proceed, but address warnings when possible.');
    }
    
    console.log('\n' + '='.repeat(60));
    
    return {
      passed,
      status: this.status,
      failures: this.failures,
      warnings: this.warnings,
      score: passedChecks / totalChecks
    };
  }
}

// CLI execution
async function runCheckpointVerification() {
  const verifier = new CheckpointVerifier();
  const report = await verifier.verifyCheckpoint();
  
  // Exit with appropriate code
  process.exit(report.passed ? 0 : 1);
}

if (require.main === module) {
  runCheckpointVerification().catch(console.error);
}

module.exports = { CheckpointVerifier }; 